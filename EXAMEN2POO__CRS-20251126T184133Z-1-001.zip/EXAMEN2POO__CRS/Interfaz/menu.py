def menuVehiculos():
    print("- VEHICULOS -")
    print("  1. Listado de vehiculos")
    print("  2. Agregar vehiculo")
    print("  3. Modificar  matricula de vehiculo")
    print("  4. Eliminar vehiculo")
    print("  5. Salir")
    
def menuSolicitudes():
    print("- SOLICITUDES -")
    print("  1. Listado de solicitudes")
    print("  2. Agregar solicitud")
    print("  3. Modificar estado de solicitud")
    print("  4. Eliminar solicitud")
    print("  5. Salir")
    
    
