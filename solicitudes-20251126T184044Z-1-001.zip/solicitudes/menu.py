def menuSolicitudes():
    print("\n   - SOLICITUDES -")
    print("     1. Listado de solicitudes")
    print("     2. Agregar solicitud")
    print("     3. Modificar estado de solicitud")
    print("     4. Modificar solicitud")
    print("     5. Salir")