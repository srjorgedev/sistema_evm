
def _Usuarios():
    print("- USUARIOS -")
    print("  1. Registrar usuario")
    print("  2. Listado de usuarios")
    print("  3. Actualizar Usuarios")
    print("  4. Eliminar Usuarios")
    print("  5. Volver")


def _Listado():
    print("  Listado de usuarios")
    print("  1. Administradores ")
    print("  2. Choferes")
    print("  3. Vigilante ")
    print("  4. Usuario ")
    print("  5. Volver ")

def _Tipos():
    print("  Tipos de Usuario: ")
    print("  1. Administradores ")
    print("  2. Choferes")
    print("  3. Vigilante ")
    print("  4. Usuario ")
    print("  5. Volver ")

def licencias():
    print()
    print("Seleccione el tipo de licencia del chofer: ")
    print("1. Tipo A (Automovilista): Para la conducción de vehículos particulares, como autos, camionetas y motocicletas.")
    print()
    print("2. Tipo B (Taxis y aplicaciones): Para conductores de taxis y servicios de transporte de pasajeros a través de plataformas tecnológicas.")
    print()
    print("3. Tipo C (Transporte público): Para operar vehículos de transporte colectivo de pasajeros como microbuses, minibuses y vagonetas.")
    print()
    print("4. Tipo D (Transporte de carga): Para la conducción de camiones de carga. ")
    print()
    print("5. Tipo E (Servicios especializados y de carga pesada): Para transporte especializado, como pipas, o para carga pesada como tráileres y doble remolque. ")
    print()
    
def datos():
    print("1. Nombre")
    print("2. Telefono")
    print("3. Tipo de Empleado")
    print("4. Volver")