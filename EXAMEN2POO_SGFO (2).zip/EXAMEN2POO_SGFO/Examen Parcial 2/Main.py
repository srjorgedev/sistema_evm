from Interfaz.Menu import _Usuarios
from Interfaz import fUsuarios



_Usuarios()
opc15 = int(input("Seleccione una opcion: "))
match opc15:
    case 1:
        fUsuarios.createUser()
    case 2:
        fUsuarios.selectUser()
    case 3:
        fUsuarios.updateUser()
    case 4:
        fUsuarios.deleteUser()
    case 5:
        print("Saliendo del Menu de Usuarios...")

